import unittest
from TestUtils import TestParser

class ParserSuite(unittest.TestCase):



    def test_binary_expression_8(self):
        """test binary: and --ZERO--"""
        input = """
            PROCEDURE main(); 
                BEGIN 
                    if (9 > 4) and (5 > 6) then
                        putIntLn("Then Statement");
                    else
                        putIntLn("Minh Tham");
                END
            """
        expect = "Minh Tham"
        self.assertTrue(TestParser.test(input,expect,508))  