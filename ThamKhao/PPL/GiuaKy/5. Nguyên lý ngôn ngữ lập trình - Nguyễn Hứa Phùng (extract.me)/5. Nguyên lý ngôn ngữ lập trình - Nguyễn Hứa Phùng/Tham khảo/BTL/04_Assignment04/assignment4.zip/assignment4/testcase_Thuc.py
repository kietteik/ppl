import unittest
from TestUtils import TestCodeGen
from AST import *


class CheckCodeGenSuite(unittest.TestCase):
	def test_0(self):
		input = '''Procedure main();
		var x:integer;
		y:integer;
		begin
			x:=0;
			y:=0;
				while(x<5) do begin
					if x=2 then break; 
					x:=x+1;
				end
			putInt(x);
		end'''
		expect = "2"
		self.assertTrue(TestCodeGen.test(input,expect,500))
	def test_1(self):
		input = '''Procedure main();
		var x:integer;
		y:integer;
		begin
			x:=0;
			y:=0;
				for x:=1 to 3 do begin
					if x=2 then continue;
					putInt(x);
				end
		end'''
		expect = "13"
		self.assertTrue(TestCodeGen.test(input,expect,502))
	def test_3(self):
		input = '''Procedure main();
		var x:integer;
		y:integer;
		begin
			x:=0;
			y:=0;
				for x:=1 to 3 do begin
					if x=2 then break;
					putInt(x);
				end
				
		end'''
		expect = "1"
		self.assertTrue(TestCodeGen.test(input,expect,503))
	def test_4(self):
		input = '''Procedure main();
		var x:integer;
		y:integer;
		i:integer;
		begin
			i:=0;
			with a:integer; do begin
				for a:=1 to 3 do begin
					if a=2 then break;
					i:=i+1;
				end
				i:=i*2;
			end
			putInt(i);
		end'''
		expect = "2"
		self.assertTrue(TestCodeGen.test(input,expect,504))
	def test_5(self):
		input = '''
		procedure foo(i:integer);
		begin
			putInt(i);
		end
		Procedure main();
		begin
			foo(123);
		end'''
		expect = "123"
		self.assertTrue(TestCodeGen.test(input,expect,505))
	def test_6(self):
		input = '''
		procedure foo(i:integer);
		var a:integer;
		begin
			a:=0;
			for a:=1 to 5 do begin
				i:=i*2;
			end
			putInt(i);
		end
		Procedure main();
		begin
			foo(123);
		end'''
		expect = "3936"
		self.assertTrue(TestCodeGen.test(input,expect,506))
	def test_7(self):
		input = '''
		function foo(i:integer):integer;
		begin
			if i=2 then 
				return i+1;
			else
				return i;
		end
		Procedure main();
		begin
			putInt(foo(3));
		end'''
		expect = "3"
		self.assertTrue(TestCodeGen.test(input,expect,507))
	def test_8(self):
		input = '''
		function foo(i:integer):integer;
		var a:integer;
		begin
			for a:=0 to 5 do
				return i;
			return i;
		end
		Procedure main();
		begin
			putInt(foo(3));
		end'''
		expect = "3"
		self.assertTrue(TestCodeGen.test(input,expect,508))
	def test_9(self):
		input = '''
		function foo(i:integer):integer;
		var a:integer;
		begin
			a:=0;
			for a:=0 to 5 do begin
				i:=i*0;
			end
		return i;
		end
		Procedure main();
		begin
			putInt(foo(3));
		end'''
		expect = "0"
		self.assertTrue(TestCodeGen.test(input,expect,509))
	def test_10(self):
		input = '''
		function foo(i:integer):integer;
		var a:integer;
		begin
			a:=0;
			while(true) do
			return 6;
			return 7;
			
		end
		Procedure main();
		begin
			putInt(foo(3));
		end'''
		expect = "6"
		self.assertTrue(TestCodeGen.test(input,expect,510))
	def test_11(self):
		input = '''
		Procedure main();
		begin
			putString("Hello");
		end'''
		expect = "Hello"
		self.assertTrue(TestCodeGen.test(input,expect,511))
	def test_512(self):
		input = '''
		Procedure main();
		begin
			with a:boolean; do begin
			a:=true;
			putBool(a);
			end
			
		end'''
		expect = "true"
		self.assertTrue(TestCodeGen.test(input,expect,512))
	def test_513(self):
		input = '''
		var b:integer;
		Procedure main();
		begin
			b:=0;
			putInt(b);
		end'''
		expect = "0"
		self.assertTrue(TestCodeGen.test(input,expect,513))
	def test_514(self):
		input = '''
		Procedure main();
		var a:integer;
		b,c,d,e:integer;
		begin
		a:=b:=c:=d:=e:=1;
		putInt(a+b+c+d+e);
		end'''
		expect = "5"
		self.assertTrue(TestCodeGen.test(input,expect,514))
	def test_515(self):
		input = '''
		Function foo(i:integer):integer;
		begin
			if i=0 then
				i:=i*2;
			else
				i:=i+2;
			return i;
		end
		Procedure main();
		var a:integer;
		b,c,d,e:integer;
		begin
		a:=foo(5);
		putInt(a);
		end'''
		expect = "7"
		self.assertTrue(TestCodeGen.test(input,expect,515))
	def test_16(self):
		input = '''
		Function foo(i:integer):integer;
		begin
			if i=0 then
				i:=i*2;
			else
				i:=i+2;
			return i;
		end
		Procedure main();
		var a:real;
		begin
		a:=2*2.0;
		putFloat(a);
		end'''
		expect = "4.0"
		self.assertTrue(TestCodeGen.test(input,expect,516))
	def test_17(self):
		input = '''
		Function foo(i:integer):integer;
		begin
			if i=0 then
				i:=i*2;
			else
				i:=i+2;
			return i;
		end
		Procedure main();
		var a:real;
		begin
		a:=foo(3)*foo(2);
		putFloat(a);
		end'''
		expect = "20.0"
		self.assertTrue(TestCodeGen.test(input,expect,517))
	def test_18(self):
		input = '''
		Function foo(i:integer):integer;
		begin
				if i=0 then 
				begin
					i:=i+2;
					if i=2 then begin
						i:=i*2;
						return i;
						end
					else begin
						i:=i+1;
						return i;
					end
				end
				else
				return i;
				
		end
		Procedure main();
		var a:real;
		begin
		a:=foo(0);
		putFloat(a);
		end'''
		expect = "4.0"
		self.assertTrue(TestCodeGen.test(input,expect,518))
	def test_19(self):
		input = '''
		Function foo(i:integer):integer;
		begin
				for i:=0 to 5 do 
				return i;
				if i=2 then return 2;
				else return 3;
				
		end
		Procedure main();
		var a:real;
		begin
		a:=foo(5);
		putFloat(a);
		end'''
		expect = "0.0"
		self.assertTrue(TestCodeGen.test(input,expect,519))
	def test_20(self):
		input = '''
		Function foo(i:integer):integer;
		begin
				if i=2 then return i;
				else i:=0;
				if i=0 then return 1;
				else return 2;
				
		end
		Procedure main();
		var a:real;
		begin
		a:=foo(5);
		putFloat(a);
		end'''
		expect = "1.0"
		self.assertTrue(TestCodeGen.test(input,expect,520))
	def test_21(self):
		input = '''
		Function foo(i:integer):integer;
		begin
				if i=1 then return 1;
				else 
				return i*foo(i-1);
		end
		Procedure main();
		var a:integer;
		begin
		a:=foo(5);
		putInt(a);
		end'''
		expect = "120"
		self.assertTrue(TestCodeGen.test(input,expect,521))
	def test_22(self):
		input = '''
		Function foo(i:integer):integer;
		begin 
		if (i=1) or (i=2) then return 1;
		else return foo(i-1)+foo(i-2);
		end
		Procedure main();
		var a:integer;
		begin
		a:=foo(5);
		putInt(a);
		end'''
		expect = "5"
		self.assertTrue(TestCodeGen.test(input,expect,522))
	def test_23(self):
		input = '''
		Procedure main();
		var s:string;
		begin
		s:="asd";
		putString(s);
		end'''
		expect = "asd"
		self.assertTrue(TestCodeGen.test(input,expect,523))
	def test_24(self):
		input = '''
		Procedure main();
		var a:integer;
		begin
		a:=5;
		if (a<>0) and then ((10/a)=2) then putInt(10);
		else putInt(a);
		end'''
		expect = "10"
		self.assertTrue(TestCodeGen.test(input,expect,524))
	def test_25(self):
		input = '''
		function foo(i:integer):boolean;
		begin
			with a:integer; do
			begin
				a:=1;
				return True;
			end
		end
		Procedure main();
		var x:integer;
		y:integer;
		begin
			putBool(foo(2));
		end'''
		expect = "true"
		self.assertTrue(TestCodeGen.test(input,expect,525))
	def test_26(self):
		input = '''
		function foo(i:integer):String;
		begin
			with a:integer; do
			begin
				a:=1;
				return "YES";
			end
		end
		Procedure main();
		var x:integer;
		y:integer;
		begin
			putString(foo(2));
		end'''
		expect = "YES"
		self.assertTrue(TestCodeGen.test(input,expect,526))
	def test_27(self):
		input = '''
		function foo(i:real):real;
		var a:integer;
		begin
			for a:=0 to 5 do
				i:=i+1;
			return i;
		end
		Procedure main();
		var x:integer;
		y:integer;
		begin
			putFloat(foo(2));
		end'''
		expect = "8.0"
		self.assertTrue(TestCodeGen.test(input,expect,527))
	def test_28(self):
		input = '''
		function fs(i:real):real;
		begin
			if i=2 then return i;
			else i:=i*2;
			if i=8 then i:=i+2;
			else return i;
			if i=10 then return i;
			else return i;
		end
		function foo(i:real):real;
		var a:integer;
		begin
			return fs(i);
		end
		Procedure main();
		var x:integer;
		begin
			putFloat(foo(2));
		end'''
		expect = "2.0"
		self.assertTrue(TestCodeGen.test(input,expect,528))
	def test_29(self):
		input = '''
		Procedure main();
		var x:integer;
		begin
			putFloat(1 + ( 2 + ( 3.0  +  ( 4 / 5 ) )  ) ); 
		end'''
		expect = "6.8"
		self.assertTrue(TestCodeGen.test(input,expect,529))
	def test_30(self):
		input = '''
		var i:integer;
		Procedure main();
		var x:real;
		begin
			i:=100;
			x:=i+10;
			x:=x/2;
			putFloat(x); 
		end'''
		expect = "55.0"
		self.assertTrue(TestCodeGen.test(input,expect,530))
	def test_31(self):
		input = '''
		function pool():boolean;
		begin
			return false;
		end
		Procedure main();
		begin
			putBool(True and pool()); 
		end'''
		expect = "false"
		self.assertTrue(TestCodeGen.test(input,expect,531))
	def test_31(self):
		input = '''
		function pool(i:integer;j:integer):integer;
		begin
			return i+j;
		end
		Procedure main();
		begin
			putInt(pool(1,2)); 
		end'''
		expect = "3"
		self.assertTrue(TestCodeGen.test(input,expect,531))
	def test_32(self):
		input = '''
		function pool(i:integer;j:integer):integer;
		begin
			return i+j;
		end
		var i:integer;
		Procedure main();
		begin
			i:=0;
			while(i<10)do
			begin
				i:=i+1;
				if i=3 then continue;
				putInt(i);
				if i=5 then break;
			end
		end'''
		expect = "1245"
		self.assertTrue(TestCodeGen.test(input,expect,532))
	def test_33(self):
		input = '''
		function pool(a:integer):integer;
		begin
			for a:=6 downto 0 do 
			begin
				if a=6 then break;
			end
			return a*2;
		end
		var i:integer;
		Procedure main();
		begin
			putInt(pool(0));
		end'''
		expect = "12"
		self.assertTrue(TestCodeGen.test(input,expect,533))
