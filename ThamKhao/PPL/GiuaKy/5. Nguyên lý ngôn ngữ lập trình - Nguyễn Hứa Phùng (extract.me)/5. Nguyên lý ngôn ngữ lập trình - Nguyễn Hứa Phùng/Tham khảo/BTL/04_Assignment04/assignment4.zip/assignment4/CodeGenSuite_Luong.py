import unittest
from TestUtils import TestCodeGen
from AST import *


class CheckCodeGenSuite(unittest.TestCase):
	def test_int_ast_1(self):
		input = """
		function foo(a:integer):integer;
		begin
			return a;
		end
		procedure main();begin putInt(foo(5)); end
					"""
		expect = "5"
		self.assertTrue(TestCodeGen.test(input,expect,501))

	def test_int_ast_2(self):
		input = """
		function foo():integer;
		var a:integer;
		begin
			a:=10;
			return a;
		end
		procedure main();
		begin putInt(foo()); end
					"""
		expect = "10"
		self.assertTrue(TestCodeGen.test(input,expect,502))

	def test_int_ast_3(self):
		input = """
		function foo(a:integer):integer;
		begin
			a:=a+1;
			return a;
		end
		procedure main();
		var a:integer;
		begin 
		a:=5;
		putInt(foo(a)); 
		end
					"""
		expect = "6"
		self.assertTrue(TestCodeGen.test(input,expect,503))

	def test_int_ast_4(self):
		input = """
		procedure main();
					var a:integer;
					begin
						a:=10;
						while(a > 1) do
						begin
							if(a < 2) then break;
							a:=a-1;
						end
						putInt(a);
					end
					"""
		expect = "1"
		self.assertTrue(TestCodeGen.test(input,expect,504))

	def test_int_ast_5(self):
		input = """
		procedure main();
					var a,b:integer;
					begin
						a:=10;
						b:=a;
						putInt(b);
					end
					"""
		expect = "10"
		self.assertTrue(TestCodeGen.test(input,expect,505))

	def test_int_ast_6(self):
		input = """
		procedure main();
					var a,b:integer;
					begin
						a:=10;
						b:=0;
						while(a > 1) do
						begin
							if(a < 3) then begin b:=a; break; end
							a:=a-1;
						end
						putInt(b);
					end
					"""
		expect = "2"
		self.assertTrue(TestCodeGen.test(input,expect,506))

	def test_int_ast_7(self):
		input = """
		procedure main();
					var a,b,c:integer;
					begin
						a:=10;
						b:=0;
						c:=a+b;
						putInt(c);
					end
					"""
		expect = "10"
		self.assertTrue(TestCodeGen.test(input,expect,507))

	def test_int_ast_8(self):
		input = """
		procedure main();
					var a,b,c:integer;
					begin
						a:=10;
						b:=0;
						c:=a-b;
						putInt(c);
					end
					"""
		expect = "10"
		self.assertTrue(TestCodeGen.test(input,expect,508))

	def test_int_ast_9(self):
		input = """
		procedure main();
					var a,b,c:integer;
					begin
						a:=10;
						b:=0;
						c:=a*b;
						putInt(c);
					end
					"""
		expect = "0"
		self.assertTrue(TestCodeGen.test(input,expect,509))

	def test_int_ast_10(self):
		input = """
		procedure main();
					var a,b,c:integer;
					begin
						a:=10;
						b:=0;
						c:=b/a;
						putInt(c);
					end
					"""
		expect = "0"
		self.assertTrue(TestCodeGen.test(input,expect,510))

	def test_int_ast_10(self):
		input = """
		procedure main();
					var a,b,c:integer;
					begin
						a:=10;
						b:=0;
						c:=b div a;
						putInt(c);
					end
					"""
		expect = "0"
		self.assertTrue(TestCodeGen.test(input,expect,510))

	def test_int_ast_11(self):
		input = """
		procedure main();
					var a,b,c:integer;
					begin
						a:=10;
						b:=8;
						c:=a mod b;
						putInt(c);
					end
					"""
		expect = "2"
		self.assertTrue(TestCodeGen.test(input,expect,511))

	def test_int_ast_12(self):
		input = """
		procedure main();
					var a:integer;b,c:real;
					begin
						a:=1;
						b:=2.0;
						c:=a + b;
						putFloat(c);
					end
					"""
		expect = "3.0"
		self.assertTrue(TestCodeGen.test(input,expect,512))

	def test_int_ast_13(self):
		input = """
		procedure main();
					var a:integer;b,c:real;
					begin
						a:=1;
						b:=2.0;
						c:=a - b;
						putFloat(c);
					end
					"""
		expect = "-1.0"
		self.assertTrue(TestCodeGen.test(input,expect,513))

	def test_int_ast_14(self):
		input = """
		procedure main();
					var a:integer;
					begin
						a:=1;
						if(not(false)) then a:= a + 1;
						putInt(a);
					end
					"""
		expect = "2"
		self.assertTrue(TestCodeGen.test(input,expect,514))

	def test_int_ast_15(self):
		input = """
		procedure main();
					var a:integer;
					begin
						a:=5;
						if(a > 1 and then a < 6) then a:= a + 1;
						putInt(a);
					end
					"""
		expect = "6"
		self.assertTrue(TestCodeGen.test(input,expect,515))

	def test_int_ast_16(self):
		input = """
		procedure main();
					var a:integer;
					begin
						a:=5;
						if(a < 6 or else a > 10) then a:= a + 1;
						putInt(a);
					end
					"""
		expect = "6"
		self.assertTrue(TestCodeGen.test(input,expect,516))

	def test_int_ast_17(self):
		input = """
		procedure main();
					var a:integer;
					begin
						a:=5;
						if(a < 6) then a:= a + 1; else begin a:= a * 2; end
						putInt(a);
					end
					"""
		expect = "6"
		self.assertTrue(TestCodeGen.test(input,expect,517))

	def test_int_ast_18(self):
		input = """
		procedure main();
					var a:integer;
					begin
						a:=5;
						if(a > 6) then a:= a + 1; else begin a:= a * 2; end
						putInt(a);
					end
					"""
		expect = "10"
		self.assertTrue(TestCodeGen.test(input,expect,518))

	def test_int_ast_19(self):
		input = """
		function foo():integer;
					var a:integer;
					begin
						a:=2;
						if (a<6) then 
						begin
							a:=a+1;
							return a;
						end
						else
						begin
							a:=a*2;
							return a;
						end
					end
		procedure main();begin putInt(foo()); end
					"""
		expect = "3"
		self.assertTrue(TestCodeGen.test(input,expect,519))

	def test_int_ast_20(self):
		input = """
		function foo():integer;
					var a:integer;
					begin
						a:=2;
						if (a>6) then 
						begin
							a:=a+1;
							return a;
						end
						else
						begin
							a:=a*2;
							return a;
						end
					end
		procedure main();begin putInt(foo()); end
					"""
		expect = "4"
		self.assertTrue(TestCodeGen.test(input,expect,520))

	def test_int_ast_21(self):
		input = """
		function foo():integer;
					var a:integer;
					begin
						a:=2;
						if (a<6) then 
						begin
							a:=a+3;
							if (a>3) then return a; else return 1;
						end
						else
						begin
							a:=a*2;
							return a;
						end
					end
		procedure main();begin putInt(foo()); end
					"""
		expect = "5"
		self.assertTrue(TestCodeGen.test(input,expect,521))

	def test_int_ast_22(self):
		input = """
		function foo():integer;
					var a:integer;
					begin
						a:=2;
						if (a<6) then 
						begin
							a:=a-1;
							if (a>3) then return a; else return 1;
						end
						else
						begin
							a:=a*2;
							return a;
						end
					end
		procedure main();begin putInt(foo()); end
					"""
		expect = "1"
		self.assertTrue(TestCodeGen.test(input,expect,522))

	def test_int_ast_23(self):
		input = """
		procedure main();begin putInt(-2+5); end
					"""
		expect = "3"
		self.assertTrue(TestCodeGen.test(input,expect,523))

	def test_int_ast_24(self):
		input = """
		procedure main();begin putBool(3<4); end
					"""
		expect = "true"
		self.assertTrue(TestCodeGen.test(input,expect,524))

	def test_int_ast_25(self):
		input = """
		procedure main();begin putBool(3 = 3); end
					"""
		expect = "true"
		self.assertTrue(TestCodeGen.test(input,expect,525))

	def test_int_ast_26(self):
		input = """
		procedure main();begin putBool(3 = 4); end
					"""
		expect = "false"
		self.assertTrue(TestCodeGen.test(input,expect,526))

	def test_int_ast_27(self):
		input = """
		procedure main();begin putBool(3 <> 4); end
					"""
		expect = "true"
		self.assertTrue(TestCodeGen.test(input,expect,527))

	def test_int_ast_28(self):
		input = """
		procedure main();begin putBool(3 <> 3); end
					"""
		expect = "false"
		self.assertTrue(TestCodeGen.test(input,expect,528))

	def test_int_ast_29(self):
		input = """
		procedure main();begin putBool(2 <= 5.0); end
					"""
		expect = "true"
		self.assertTrue(TestCodeGen.test(input,expect,529))

	def test_int_ast_30(self):
		input = """
		procedure main();begin putBool(5.0 <= 4.0); end
					"""
		expect = "false"
		self.assertTrue(TestCodeGen.test(input,expect,530))

	def test_int_ast_31(self):
		input = """
		procedure main();begin putBool(false or else true); end
					"""
		expect = "true"
		self.assertTrue(TestCodeGen.test(input,expect,531))

	def test_int_ast_32(self):
		input = """
		procedure main();begin putString("ppl is easy"); end
					"""
		expect = "ppl is easy"
		self.assertTrue(TestCodeGen.test(input,expect,532))

	def test_int_ast_33(self):
		input = """
		function foo():integer;
		var a:integer;
		begin
			a:=1;
			a:=a+3;
			return a;
		end
		procedure main();
		var a,b:integer;
		begin 
		a:=5;
		b:=foo();
		putInt(b); 
		end
					"""
		expect = "4"
		self.assertTrue(TestCodeGen.test(input,expect,533))

	def test_int_ast_34(self):
		input = """
		function foo(b:integer):integer;
		var a:integer;
		begin
			a:=1;
			a:=b+3;
			return a;
		end
		procedure main();
		var a,b:integer;
		begin 
		a:=4;
		b:=foo(a);
		putInt(b); 
		end
					"""
		expect = "7"
		self.assertTrue(TestCodeGen.test(input,expect,534))

	def test_int_ast_35(self):
		input = """
		procedure foo(b:integer);
		begin
			putInt(b);
		end
		procedure main();
		var a,b:integer;
		begin 
		a:=4;
		foo(a);
		end
					"""
		expect = "4"
		self.assertTrue(TestCodeGen.test(input,expect,535))

	def test_int_ast_36(self):
		input = """
		procedure foo(b:integer);
		var a:integer;
		begin
			a:=1;
			a:=a+b;
			putInt(a);
		end
		procedure main();
		var a,b:integer;
		begin 
		a:=4;
		foo(a);
		end
					"""
		expect = "5"
		self.assertTrue(TestCodeGen.test(input,expect,536))

	def test_int_ast_37(self):
		input = """
		procedure main();
		var a,b:integer;
		begin 
		a:=5;
		while a>1 do
		begin
			if a<3 then break;
			a:=a-1;
		end
		putInt(a);
		end
					"""
		expect = "2"
		self.assertTrue(TestCodeGen.test(input,expect,537))

	def test_int_ast_38(self):
		input = """
		procedure main();
		var a,b:integer;
		begin 
		a:=5;
		for b:= 1 to 5 do
		begin
			a:=a-1;
		end
		putInt(a);
		end
					"""
		expect = "0"
		self.assertTrue(TestCodeGen.test(input,expect,538))

	def test_int_ast_39(self):
		input = """
		procedure main();
		var a,b:integer;
		begin 
		a:=5;
		for b:= 1 to 5 do
		begin
			a:=a-1;
			if(b>3) then break; else continue;
		end
		putInt(a);
		end
					"""
		expect = "1"
		self.assertTrue(TestCodeGen.test(input,expect,539))

	def test_int_ast_40(self):
		input = """
		procedure main();
		var a,b:integer;
		begin 
		a:=0;
		for b:= 5 downto 1 do
		begin
			a:=a+b;
		end
		putInt(a);
		end
					"""
		expect = "15"
		self.assertTrue(TestCodeGen.test(input,expect,540))
