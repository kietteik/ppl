import unittest
from TestUtils import TestLexer

class LexerSuite(unittest.TestCase):
      
    """ test ID """
    def test_id_1(self):
        self.assertTrue(TestLexer.checkLexeme("a","a,<EOF>",1))
        
    def test_id_2(self):
        self.assertTrue(TestLexer.checkLexeme("aZ_","aZ_,<EOF>",2))
    
    def test_id_3(self):
        self.assertTrue(TestLexer.checkLexeme("a2","a2,<EOF>",3))
     
    def test_id_4(self):
        self.assertTrue(TestLexer.checkLexeme("A2","Error Token A",4))
        
    def test_id_5(self):
        self.assertTrue(TestLexer.checkLexeme("a*","a,*,<EOF>",5))
    
    def test_id_6(self):
        self.assertTrue(TestLexer.checkLexeme("Var: a = 0;","Var,:,a,=,0,;,<EOF>",6))

    """ TEST KEYWORDS """
    def test_keyword(self):
        self.assertTrue(TestLexer.checkLexeme("""Body Break Continue Do Else ElseIf EndBody EndIf EndFor
        EndWhile For Function If Parameter Return Then Var While True False""",
        """Body,Break,Continue,Do,Else,ElseIf,EndBody,EndIf,EndFor,EndWhile,For,Function,If,Parameter,Return,Then,Var,While,True,False,<EOF>""",8))

    """ TEST Operators """
    def test_keyword(self):
        self.assertTrue(TestLexer.checkLexeme("""+ +. - -. * *. \ / % ! && || == != < > <= >= <. >. =/= <. >. <=. >=.""",
        """+,+.,-,-.,*,*.,\,/,%,!,&&,||,==,!=,<,>,<=,>=,<.,>.,=/=,<.,>.,<=.,>=.,<EOF>""",8))
    
    """ TEST COMMENTS """
    def test_keyword_1(self):
        self.assertTrue(TestLexer.checkLexeme("""** This is the comment**""","""<EOF>""",9))

    """ TEST COMMENTS """
    def test_keyword_2(self):
        self.assertTrue(TestLexer.checkLexeme("""** This is *the\\?123 * - as1 123 131 12xcxs 
        * asfaf asf af saf af
        * comment**""","""<EOF>""",10))

    """test floats"""
    def test_int_decimal(self):
        self.assertTrue(TestLexer.checkLexeme("11232","11232,<EOF>",11))

    def test_int_double_zeros(self):
        self.assertTrue(TestLexer.checkLexeme("001","001,<EOF>",12))

    def test_int_hex(self):
        self.assertTrue(TestLexer.checkLexeme("0x0","0x0,<EOF>",13))

    def test_int_hex_2(self):
        self.assertTrue(TestLexer.checkLexeme("0x0F","0x0F,<EOF>",14))

    def test_int_octal_1(self):
        self.assertTrue(TestLexer.checkLexeme("0o4","0o4,<EOF>",15))

    def test_int_octal_2(self):
        self.assertTrue(TestLexer.checkLexeme("0O1234567","0O1234567,<EOF>",16))

    """test floats"""
    def test_float_with_e1(self):
        self.assertTrue(TestLexer.checkLexeme("12.0e3","12.0e3,<EOF>",17))

    def test_float_with_e2(self):
        self.assertTrue(TestLexer.checkLexeme("12.E3","12.E3,<EOF>",18))

    def test_float_with_e3(self):
        self.assertTrue(TestLexer.checkLexeme("12e3","12e3,<EOF>",19))
    
    def test_float_with_e4(self):
        self.assertTrue(TestLexer.checkLexeme("12.e5","12.e5,<EOF>",20))
        
    def test_float_with_e5(self):
        self.assertTrue(TestLexer.checkLexeme("120000e-1","120000e-1,<EOF>",21))
        
    def test_float_without_decimal(self):
        self.assertTrue(TestLexer.checkLexeme("12000.","12000.,<EOF>",22))

    def test_float_with(self):
        self.assertTrue(TestLexer.checkLexeme("12000.1231","12000.1231,<EOF>",23))

    """test bool"""
    def test_bool_true(self):
        self.assertTrue(TestLexer.checkLexeme("True","True,<EOF>",24))

    def test_bool_false(self):
        self.assertTrue(TestLexer.checkLexeme("False","False,<EOF>",25))

    """ TEST SEPERATORS """
    def test_seperators(self):
        self.assertTrue(TestLexer.checkLexeme("""()[]:.,;""","""(,),[,],:,.,,,;,<EOF>""",26))

    """ STRING TEST """
    def test_empty_string(self):
        self.assertTrue(TestLexer.checkLexeme(""" "" """,""",<EOF>""",27))

    def test_string_with_quote(self):
        self.assertTrue(TestLexer.checkLexeme(""" "He asked me: '"Where is John?'"" ""","""He asked me: '"Where is John?'",<EOF>""",28))

    def test_string_with_tab(self):
        self.assertTrue(TestLexer.checkLexeme(""" "This is a string containing tab \t" ""","""This is a string containing tab \t,<EOF>""",29))

    """ TEST VARDECLAR """
    def test_var_declar_1(self):
        self.assertTrue(TestLexer.checkLexeme("Var: a = 0, b;","Var,:,a,=,0,,,b,;,<EOF>",30))

    def test_var_declar_2(self):
        self.assertTrue(TestLexer.checkLexeme("""Var: a[2] = 0, b="abc";""",
        "Var,:,a,[,2,],=,0,,,b,=,abc,;,<EOF>",31))

    def test_var_declar_3(self):
        self.assertTrue(TestLexer.checkLexeme("""Var: a[2] = 0, b="abc";""",
        "Var,:,a,[,2,],=,0,,,b,=,abc,;,<EOF>",32))

    def test_var_declar_4(self):
        self.assertTrue(TestLexer.checkLexeme("Var: a[0];",
        "Var,:,a,[,0,],;,<EOF>",33))

    def test_var_declar_4(self):
        self.assertTrue(TestLexer.checkLexeme("Var: a[0];",
        "Var,:,a,[,0,],;,<EOF>",34))

    def test_assignment(self):
        self.assertTrue(TestLexer.checkLexeme("a[0] = !(x==a);",
        "a,[,0,],=,!,(,x,==,a,),;,<EOF>",35))

    def test_assignment_2(self):
        self.assertTrue(TestLexer.checkLexeme("aA_0_=!(x== (a + 2 / 3));",
        "aA_0_,=,!,(,x,==,(,a,+,2,/,3,),),;,<EOF>",36))

    def test_assignment_3(self):
        self.assertTrue(TestLexer.checkLexeme("a[5][3][5]=!(x== (a + 2 / 3));",
        "a,[,5,],[,3,],[,5,],=,!,(,x,==,(,a,+,2,/,3,),),;,<EOF>",37))
        
    def test_assignment_4(self):
        self.assertTrue(TestLexer.checkLexeme("a=2.13e123;",
        "a,=,2.13e123,;,<EOF>",38))

    def test_assignment_5(self):
        self.assertTrue(TestLexer.checkLexeme("a=2.13*.123.4;",
        "a,=,2.13,*.,123.4,;,<EOF>",39))

    def test_assignment_6(self):
        self.assertTrue(TestLexer.checkLexeme("a=2.13%123.;",
        "a,=,2.13,%,123.,;,<EOF>",40))


    def test_1_invalid_real(self):
        """ Test Invalid Real Literal """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
e-12 e12 . 1e 12e 12.05e .05e ee e01
""",
            "e,-,12,e12,.,1,e,12,e,12.05,e,.,05,e,ee,e01,<EOF>",
            41
        ))
        
    def test_1_unclose_without_endline(self):
        """ Test Unclose String without endline """
        self.assertTrue(TestLexer.checkLexeme(
            r"""  " hello lexer """,

            "Unclosed String:  hello lexer ",
            42
        ))
        

    def test_2_unclose_with_endline(self):
        """ Test Unclose String with endline """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
" abcxyz
""",

            r"""Unclosed String:  abcxyz""",
            43
        ))
        

    def test_1_escape(self):
        """ Test Escape String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
" abc \n xyz "
" abc \\n xyz "
""",

            r''' abc \n xyz , abc \\n xyz ,<EOF>''',
            44
        ))
        

    def test_2_escape(self):
        """ Test Escape String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
" hello lexer \t "     asdf 
""",

            r' hello lexer \t ,asdf,<EOF>',
            45
        ))
        

    def test_3_escape(self):
        """ Test Escape String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"Backspace  \b"
""",

            r'Backspace  \b,<EOF>',
            46
        ))
        

    def test_4_escape(self):
        """ Test Escape String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"Formfeed   \f"
""",

            r'Formfeed   \f,<EOF>',
            47
        ))
        

    def test_5_escape(self):
        """ Test Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"Return     \r"
""",

            r'''Return     \r,<EOF>''',
            48
        ))
        

    def test_6_escape(self):
        """ Test Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"Newline    \n"
""",

            r'''Newline    \n,<EOF>''',
            49
        ))
        

    def test_7_unclose_multi_lines(self):
        """ Test Unclosed String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"Newline
    multiple lines
"           """,

            r'''Unclosed String: Newline''',
            50
        ))
        

    def test_8_escape(self):
        """ Test Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"Tab        \t"
""",

            r'Tab        \t,<EOF>',
            51
        ))
        

    def test_9_escape(self):
        """ Test Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"Backslash  \\ "
""",

            r"Backslash  \\ ,<EOF>",
            52
        ))
        

    def test_1_illegal(self):
        """ Test Illegal Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
Illegal: "\a"
""",

            r"""Error Token I""",
            53
        ))
        

    def test_2_illegal(self):
        """ Test Illegal Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
" Hi Hi \c \d "
""",

            "Illegal Escape In String:  Hi Hi \c",
            54
        ))
        

    def test_3_illegal(self):
        """ Test Illegal Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
" Hi Hi \m\n\c\s\d\\f "
""",

            "Illegal Escape In String:  Hi Hi \m",
            55
        ))
        

    def test_1_nevermind(self):
        """ Test Nevermind :) """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
" asdf ` asdf"
""",

            " asdf ` asdf,<EOF>",
            56
        ))
        
    def test_1_escape_singlequote(self):
        """ Test Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
" abc \' xyz "
""",

            r" abc \' xyz ,<EOF>",
            57
        ))
        

    def test_1_escape_doublequote(self):
        """ Test Escape String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
" abc \" xyz " ghi
""",

            r" abc \" xyz ,ghi,<EOF>",
            58
        ))
        

    def test_1_illegal(self):
        """ Test Error String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"abc" 123 af23 "abc xyz"
" abc\m "
""",

            "abc,123,af23,abc xyz,Illegal Escape In String:  abc\m",
            59
        ))
        

    def test_1_err_tok(self):
        """ Test Error Token """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
!== != & ^ % $ # ... \
""",

            "!=,=,!=,Error Token &",
            60
        ))
        

    def test_2_err_tok(self):
        """ Test Error Token """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
If a != b Then
""",

            "If,a,!=,b,Then,<EOF>",
            61
        ))
        

    def test_3_err_tok(self):
        """ Test Error Token """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
a = a & 1
""",

            "a,=,a,Error Token &",
            62
        ))
        

    def test_4_err_tok(self):
        """ Test Error Token """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
xyz
$a = 5
""",

            "xyz,Error Token $",
            63
        ))
        

    def test_4_err_tok(self):
        """ Test Error Token """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
#define for 1
""","Error Token #",64
        ))
        
    def test_1_num_leading_0(self):
        """ Test Number leading 0 """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
1234 0000001234 0000043123
""",

            "1234,0000001234,0000043123,<EOF>",
            65
        ))
        

    def test_2_num_leading_0(self):
        """ Test Real Leading 0 """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
00001.1111000000
0e-4
000000001e-40000
""",

            "00001.1111000000,0e-4,000000001e-40000,<EOF>",
            66
        ))
        

    def test_1_illegal(self):
        """ Test Error String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"abc - xyz"
"abc \ xyz"
""",

            "abc - xyz,Illegal Escape In String: abc \ ",
            67
        ))
        

    def test_2_illegal(self):
        """ Test Error String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"abc - xyz"
"abc \yyz"
""",

            "abc - xyz,Illegal Escape In String: abc \y",
            68
        ))
        

    def test_1_escape_backsplash_spacing(self):
        """ Test Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"abc \\ xyz"
""",

            r"abc \\ xyz,<EOF>",
            69
        ))
        

    def test_1_escape_backsplash_trim(self):
        """ Test Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"\\"
""",

            r'''\\,<EOF>''',
            70
        ))
        

    def test_1_escape_backsplash_tail_spacing(self):
        """ Test Escape """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"\\ "
""",

            r"\\ ,<EOF>",
            71
        ))
        

    def test_1_unclose_use_escape(self):
        """ Test Unclosed String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"\"
""",

            r"""Unclosed String: \"""",
            72
        ))
        

    def test_48_escape(self):
        """ Test Escape String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"\""
""",

            r"""\",<EOF>""",
            73
        ))
        

    def test_1_unclose_with_invalid_close(self):
        """ Test Unclosed String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
s = "string           
"a = 4
g = 9
""",

            r'''s,=,Unclosed String: string           ''',
            74
        ))
        

    def test_1_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
Function: fact
         Parameter: n
         Body:
                 If n == 0 Then
                         Return 1;
                 Else
                         Return n * fact (n - 1);
                 EndIf.
        EndBody.
""",

            "Function,:,fact,Parameter,:,n,Body,:,If,n,==,0,Then,Return,1,;,Else,Return,n,*,fact,(,n,-,1,),;,EndIf,.,EndBody,.,<EOF>",
            75
        ))
        

    def test_51_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
procedure foo();
begin
    while i do begin
        ok()
    end
end
""",

            r"procedure,foo,(,),;,begin,while,i,do,begin,ok,(,),end,end,<EOF>",
            76
        ))
        

    def test_52_unclose_eof(self):
        """ Test Unclosed String """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
s = "abc""",

            r"s,=,Unclosed String: abc",
            77
        ))
        

    def test_53_unclose_newline(self):
        """ Test Unclosed """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
s = "abc                   ;
a = "xyz"
""",

            r"""s,=,Unclosed String: abc                   ;""",
            78
        ))
        

    def test_54_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
            Function: foo
            Body:
            If n == 0 Then
            Return 1;
            Else
            Return n * fact (n - 1);
            EndIf.
            EndBody.
""",

            r"Function,:,foo,Body,:,If,n,==,0,Then,Return,1,;,Else,Return,n,*,fact,(,n,-,1,),;,EndIf,.,EndBody,.,<EOF>",
            79
        ))
        

    def test_55_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
            Function: main
            Body:
            x = 10;
            fact (x);
            fact (a[1] + 3);
            EndBody.
""",

            "Function,:,main,Body,:,x,=,10,;,fact,(,x,),;,fact,(,a,[,1,],+,3,),;,EndBody,.,<EOF>",
            80
        ))
        

    def test_56_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
            Var: a = 5, i, e = 2;
            Var: b[6];
            Var: b[6][2];
            Var: c,d, f;     
""",
            "Var,:,a,=,5,,,i,,,e,=,2,;,Var,:,b,[,6,],;,Var,:,b,[,6,],[,2,],;,Var,:,c,,,d,,,f,;,<EOF>",
            81
        ))
        

    def test_57_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
    Function: main
        Body:
                x = 10;
                fact (x);
                fact (a[1] + 3);
        EndBody.
        """,
            "Function,:,main,Body,:,x,=,10,;,fact,(,x,),;,fact,(,a,[,1,],+,3,),;,EndBody,.,<EOF>",
            82
        ))
        

    def test_58_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
            Function: main
            Parameter: a, b
            Body:
                For (i = 0, i < 10, i = i + 2) Do
                    
                EndFor.
            EndBody.
""",

            "Function,:,main,Parameter,:,a,,,b,Body,:,For,(,i,=,0,,,i,<,10,,,i,=,i,+,2,),Do,EndFor,.,EndBody,.,<EOF>",
            83
        ))
        

    def test_59_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
procedure foo();
begin
    s = "asdfghjklwertyuio  xcvbnm,dfghjkl;567"
    t = " dfghjk\n\t\rsdfghjkl\bsdfghjklfgh    "
    y = "dfghjkl 
    
    
    ";
end
""",

            r"""procedure,foo,(,),;,begin,s,=,asdfghjklwertyuio  xcvbnm,dfghjkl;567,t,=, dfghjk\n\t\rsdfghjkl\bsdfghjklfgh    ,y,=,Unclosed String: dfghjkl """,
            84
        ))
        

    def test_60_complex(self):
        """ Test Complex Function """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
procedure foo();
begin
    s = "asdfghjklwertyuio  xcvbnm,dfghjkl;567"
    t = " dfghjk\n\t\rsdfghjkl\bsdfghjklfgh    "
    y = "dfghjkl 
    
    
    ";
    begin end
    ok();
    break;
end
""",

            r"""procedure,foo,(,),;,begin,s,=,asdfghjklwertyuio  xcvbnm,dfghjkl;567,t,=, dfghjk\n\t\rsdfghjkl\bsdfghjklfgh    ,y,=,Unclosed String: dfghjkl """,
            85
        ))

    def test_62_er_tok(self):
        """ Test /* """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
/*123*/
""",

            "/,*,123,*,/,<EOF>",
            86
        ))
        

    def test_63_err_tok(self):
        """ Test Error Token """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
\\ // / \
""",

            "\,\,/,/,/,\,<EOF>",
            87
        ))
        

    def test_64_err_tok(self):
        """ Test Error Token @ """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
@1
""",

            r"Error Token @",
            88
        ))
        

    def test_65_err_tok(self):
        """ Test String @ """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"@1"
""",

            "@1,<EOF>",
            89
        ))
        

    def test_66_escape(self):
        """ Test ' " """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"\"\"\" \' \' "
""",

            r"\"\"\" \' \' ,<EOF>",
            90
        ))
        

    def test_67_err_tok(self):
        """ Test Error Token """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
%%%%%%
""",

            r"%,%,%,%,%,%,<EOF>",
            91
        ))
        

    def test_68_escape(self):
        """ Test \t """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
"\t\t\t\t\t\t\t\t"
""",

            r"\t\t\t\t\t\t\t\t,<EOF>",
            92
        ))
        

    def test_69_escape(self):
        """ Test \n  """
        self.assertTrue(TestLexer.checkLexeme(
            """
"\n\n\n\n\n\n\n\n\n a"
""",

            r"Unclosed String: ",
            93
        ))
        

    def test_70_escape(self):
        """ Test \r """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
\r\r\r\r\r\r\r\r\r\
""",

            """\,r,\,r,\,r,\,r,\,r,\,r,\,r,\,r,\,r,\,<EOF>""",
            94
        ))
        

    def test_71_err_tok(self):
        """ Test Error Token """
        self.assertTrue(TestLexer.checkLexeme(
            r"""
\.\x\\
""",

            """\,.,\,x,\,\,<EOF>""",
            95
        ))

    
    def test_block_comment_147(self):
        self.assertTrue(TestLexer.checkLexeme("** abc // 123 **","<EOF>",96))   
    def test_block_comment_148(self):
        self.assertTrue(TestLexer.checkLexeme("** abc \n 123 **","<EOF>",97))
    def test_block_comment_149(self):
        self.assertTrue(TestLexer.checkLexeme("** abc \b \t \r 123 **","<EOF>",98))

    def test_block_comment_150(self):
        self.assertTrue(TestLexer.checkLexeme("** abc \\ .. // \b \t \r 123 **","<EOF>",99))
     #test variable declaration
    def test_variabledecl_151(self):
        self.assertTrue(TestLexer.checkLexeme("Var x, a[5];","Var,x,,,a,[,5,],;,<EOF>",100))
    def test_variabledecl_152(self):
        self.assertTrue(TestLexer.checkLexeme("Var a, b, c[1], d, e[2];","Var,a,,,b,,,c,[,1,],,,d,,,e,[,2,],;,<EOF>",110))
    def test_variabledecl_153(self):
        self.assertTrue(TestLexer.checkLexeme("Var str='A string!'","Var,str,=,Error Token '",111))
    # def test_variabledecl_154(self):
    #     self.assertTrue(TestLexer.checkLexeme("""a_="this is a string" ""","a_,=,this is a string,<EOF>",154))
    def test_variabledecl_155(self):
        self.assertTrue(TestLexer.checkLexeme("a__var__123 = 456","a__var__123,=,456,<EOF>",112))
    def test_variabledecl_157(self):
        self.assertTrue(TestLexer.checkLexeme("Var x (123, string);","Var,x,(,123,,,string,),;,<EOF>",113))
    # /////////////////////////////////////////////////////////////////////////////////////
    def test_lower_identifier(self):
        """test identifiers"""
        self.assertTrue(TestLexer.checkLexeme("abc","abc,<EOF>",101))

    def test_lower_upper_id(self):
        self.assertTrue(TestLexer.checkLexeme("Var","Var,<EOF>",102))

    def test_wrong_token(self):
        self.assertTrue(TestLexer.checkLexeme("ab?svn","ab,Error Token ?",103))

    def test_integer(self):
        """test integers"""
        self.assertTrue(TestLexer.checkLexeme("Var x;","Var,x,;,<EOF>",104))


    """ TEST STRING """
    def test_illegal_escape(self):
        """test illegal escape"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\h def"  ""","""Illegal Escape In String: abc\\h""",105))

    def test_unterminated_string(self):
        """test unclosed string"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc def  ""","""Unclosed String: abc def  """,106))

    def test_normal_string_with_escape(self):
        """test normal string with escape"""
        self.assertTrue(TestLexer.checkLexeme(""" "ab'"c\\n def"  ""","""ab'"c\\n def,<EOF>""",107))

