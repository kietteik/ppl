import unittest
from TestUtils import TestParser

class ParserSuite(unittest.TestCase):
    def test_1(self):
        """Declar"""
        input = """Var: x,y;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,201))

    def test_2(self):
        """Declar"""
        input = """Var: x=0,y;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,202))

    def test_3(self):
        """Declar"""
        input = """Var: x=0,y=0;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,203))

    def test_4(self):
        """Declar"""
        input = r"""
        Var: x=0,y=0;
        Var: x=0,y=0;
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,204))

    def test_5(self):
        """Declar"""
        input = r"""
        Var: x[9]=0,y;
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,205))

    def test_6(self):
        """Declar"""
        input = r"""
        Var: x[9][2]=0,y;
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,206))


    def test_7(self):
        """Declar"""
        input = r"""
        Var: x[9][2]=0,y;
        Var: x[9][2][123]=0,y,asADASDA[234114];
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,207))
        

    def test_8(self):
        """Declar"""
        input = r"""
        Var: x[9][2]=0.123114e123,y;
        Var: x[9][2][123]=0.123e123,y="hello '"im here'"",asADASDA[234114];
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,208))
        
    def test_9(self):
        """Declar"""
        input = r"""
        Var: x[9][2]=True,y;
        Var: x[9][2][123]=False,y="hello '"im here'"",asADASDA[234114];
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,209))

    def test_10(self):
        """Empty"""
        input = r"""
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,210))

    def test_11(self):
        """Declar"""
        input = r"""
        Function: main
            Body:
            EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,211))

    def test_12(self):
        """Declar"""
        input = r"""
        Var: x[9][2]=True,y;
        Var: x[9][2][123]=False,y="hello '"im here'"",asADASDA[234114];



        Function: main
            Body:
            EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,212))

    def test_13(self):
        """Declar"""
        input = r"""

        Function: main
            Body:
            EndBody.
        Var: x[9][2][123]=False,y="hello '"im here'"",asADASDA[234114];
        """
        expect = "Error on line 6 col 8: Var"
        self.assertTrue(TestParser.checkParser(input,expect,213))

    def test_14(self):
        """Check Init value not expression"""
        input = r"""

        Var: x[9]=194+4,y="hello '"im here'"",asADASDA[234114];
        Function: main
            Body:
            EndBody.
        """
        expect = "Error on line 3 col 21: +"
        self.assertTrue(TestParser.checkParser(input,expect,214))

    def test_15(self):
        """Check function with parameter"""
        input = r"""
        Var: x[9]=19,y="hello '"im here'"",asADASDA[234114];
        Function: main
            Parameter: aAD, a_

            Body:
            EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,215))

    def test_16(self):
        """Check function with parameter"""
        input = r"""
            Function: main
            Parameter: a, b
            Body:
                    For (i = 0, i < 10, i = i + 2) Do
                        
                    EndFor.
            EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,216))
        
    def test_17(self):
        """Function with var declar"""
        input = r"""
            Function: main
            Parameter: a, b
            Body:
                Var: x=4;
                    For (i = 0, i < 10, i = i + 2) Do
                        For (i = 0, i < 10, i = i + 2) Do
                            
                        EndFor.
                    EndFor.
            EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,217))

        
    def test_18(self):
        """With comment"""
        input = r"""
            ** asasdfasf \n ? \eafasf?? **
            Function: main
            Parameter: a, b
            Body:
            ** asasdfasf \n ? \eafasf?? **
                Var: x=4;
                    For (i = 0, i < 10, i = i + 2) Do
                        For (i = 0, i < 10, i = i + 2) Do
                Var: x=4;
            ** asasdfasf \n ? \eafasf?? **
                        EndFor.
                    EndFor.
            ** asasdfasf \n ? \eafasf?? **
            EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,218))


    def test_19(self):
        """While statement"""
        input = r"""
        Function: foo
        Parameter: a[5], b
        Body:
        Var: i = 0;
        While (i < 5)
        Do
        a[i] = b;
        a = b;
        EndWhile.
        EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,219))

    def test_20(self):
        """If statement"""
        input = r"""
        Function: foo
        Parameter: a[5], b
        Body:
        Var: i = 0;
        If True Then 
            Var: i = 0;
            While (i < 5)
            Do
            a[i] = b;
            a = b;
            EndWhile.
        EndIf.
        EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,220))
        
    def test_21(self):
        """If statement"""
        input = r"""
        Function: foo
        Parameter: a[5], b
        Body:
        Var: i = 0;
        If True Then 
            Var: i = 0;
        ElseIf False Then 
            Var: a = 0;
        EndIf.
        EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,221))

    def test_22(self):
        """If statement"""
        input = r"""
        Function: foo
        Parameter: a[5], b
        Body:
        Var: i = 0;
        If True Then 
            Var: i = 0;
        ElseIf False Then 
            Var: a = 0;
        ElseIf a == (b+c)/d +. f Then 
            Var: a = 0;
        EndIf.
        EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,222))

    def test_23(self):
        """If statement"""
        input = r"""
        Function: foo
        Parameter: a[5], b
        Body:
        Var: i = 0;
        If True Then 
            Var: i = 0;
        ElseIf False Then 
            Var: a = 0;
        ElseIf a == (b+c)/d +. f Then 
            Var: a = 0;
        Else
            Var: c = 0;
            c = y >. 0;
        EndIf.
        EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,223))


    def test_24(self):
        """Do while statement"""
        input = r"""
        Function: foo
        Parameter: a[5], b
        Body:
        Var: i = 0;
        If True Then 
            Do
                i = 1 + 2;
            While (123 == 2);
            Var: i = 0;
        ElseIf False Then 
            Var: a = 0;
        ElseIf a == (b+c)/d +. f Then 
            Var: a = 0;
        Else
            Var: c = 0;
            c = y >. 0;
        EndIf.
        EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,224))

    def test_25(self):
        """Break Statement"""
        input = r"""
        Function: foo
        Parameter: a[5], b
        Body:
        Var: i = 0;
        If True Then 
            Do
                i = 1 + 2;
                Break;
            While (123 == 2);
            Var: i = 0;
        EndIf.
        EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,225))


    def test_26(self):
        """Continue Statement"""
        input = r"""
        Function: foo
        Parameter: a[5], b
        Body:
        Var: i = 0;
        If True Then 
            Do
                i = 1 + 2;
                Continue;
            While (123 == 2);
            Var: i = 0;
        EndIf.
        EndBody.
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,226))
    
    
    def test_27(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                While n[1] == a[2] Do
                **Check**
                Break;
                EndWhile.
                EndBody."""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,227))

    def test_28(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                while n[1] == a[2] Do
                **Check**
                Break;
                EndWhile.   
                EndBody."""
        expect = "Error on line 5 col 22: n"
        self.assertTrue(TestParser.checkParser(input,expect,228))

    def test_29(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                While: n[1] == a[2] Do
                **Check**
                Break;
                EndWhile.   
                EndBody."""
        expect = "Error on line 5 col 21: :"
        self.assertTrue(TestParser.checkParser(input,expect,229))

    def test_30(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                While n[1] == a[2] Do
                **Check**
                a
                EndWhile.   
                EndBody."""
        expect = "Error on line 8 col 16: EndWhile"
        self.assertTrue(TestParser.checkParser(input,expect,230))

    def test_31(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                While n[1] == a[2] Do
                **Check**
                a + b
                EndWhile.   
                EndBody."""
        expect = "Error on line 7 col 18: +"
        self.assertTrue(TestParser.checkParser(input,expect,231))

    def test_32(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                While n[1] == a[2]; Do
                **Check**
                Break;
                EndWhile.   
                EndBody."""
        expect = "Error on line 5 col 34: ;"
        self.assertTrue(TestParser.checkParser(input,expect,232))

    def test_33(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                While n[1] == a[2] Do
                **Check**
                Break;
                EndWhile
                EndBody."""
        expect = "Error on line 9 col 16: EndBody"
        self.assertTrue(TestParser.checkParser(input,expect,233))

    def test_34(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                While n[1] == a[2]
                EndBody."""
        expect = "Error on line 6 col 16: EndBody"
        self.assertTrue(TestParser.checkParser(input,expect,234))

    def test_35(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                While Do
                EndWhile.   
                EndBody."""
        expect = "Error on line 5 col 22: Do"
        self.assertTrue(TestParser.checkParser(input,expect,235))

    def test_36(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                Do x = y;
                While a > b;
                EndBody."""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,236))


    def test_37(self):
        input = """ Var: x[10];
                    Function: you
                    Parameter: x[3][4][6]
                    Body:
                    While(True)                            
                    EndWhile.
                    EndBody.
        
            """
        expect = "Error on line 6 col 20: EndWhile"
        self.assertTrue(TestParser.checkParser(input,expect,237))

    def tset_38(self):
        input = """ Var: x[4][0][10];
                    Function: me
                    Body:
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                    EndBody.
        
                    Function: main
                    Body:
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                        Var: x[4][0][10];
                    EndBody.
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,238))
    
    def test_39(self):
        input = """ Var: x = "aa", y = 2;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,239))

    def test_40(self):
        input = """ Var: x = True, y="Hi im here";"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,240))

    def test_41(self):
        input = """ Var: x = True;
                    Function: foo
                    Parameter: a, b, x[2], y[2][3]
                    Body:

                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,241))
    
    def test_42(self):
        input = """ Var: x = 1;
                    Function: foo
                    Parameter: a, b, x[2], y[2][3]
                    Body:
                        a[2] = (a + b) + x;
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,242))
    def test_43(self):
        input = """ Var: x = 1;
                    Function: foo
                    Parameter: a, b, x[2], y[2][3];
                    Body:
                        a[2] = (a + b) + x;
                    EndBody.
                    """
        expect = "Error on line 3 col 50: ;"
        self.assertTrue(TestParser.checkParser(input,expect,243))
    def test44(self):
        input = """ **This is program
                * Here is declare
                * Here for function
                **
                """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,244))

    def test_45(self):
        input = """ Var: x[4][0][10];
                    Function: foo
                    Parameter: x[3]
                    Body:
                    While(True) Do
                        i = i + 1;
                    EndWhile.
                    EndBody.
        
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,245))
    
    def test_46(self):
        input = """ Var: x[4][0][10];
                    Function: goo
                    Parameter: x[1][2]
                    Body:
                    While(True) Do
                        If (x == True) Then x = a - 1;
                        EndIf.
                    EndWhile.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,246))

    def test_47(self):
        input = """ Var: x, y = 1, e = 2., z = 3.5;
                    Var: t;
                    Var: sp, yz;
                    Function you
                    Parameter: q , d[5]
                    Body:
                    Var: a = "string", b;
                    Var: c = False;
                    foo(a + c);
                    While (True)  Do    
                        foo();
                        goo(a);
                        Break;                      
                    EndWhile.
                    For (i = 0, i < 10, i = i +2) Do
                        x = i;
                    EndFor.
                    EndBody.            
            """
        expect = "Error on line 4 col 29: you"
        self.assertTrue(TestParser.checkParser(input,expect,247))
    
    def test_48(self):
        input = """ Var: x, y = 1, 2., z = 3.5;
                    Var: t;
                    Var: sp, yz;
                    Function: you
                    Parameter: q , d[5]
                    Body:
                    Var: a = "string", b;
                    Var: c = False;
                    foo(a + c);
                    If (z == True) Then
                        x = d[y *. z +. t -. c \ 10];
                        Return 1;
                    ElseIf x != 4.e5 Then
                        x = (a + b) * y - z + (sp *. yz);
                    Else
                        Continue;
                    EndIf.
                    While (True)  Do    
                        foo();
                        goo(a);
                        Break;                      
                    EndWhile.
                    For (i = 0, i < 10, i = i +2) 
                    EndFor.
                    EndBody.            
            """
        expect = "Error on line 1 col 16: 2."
        self.assertTrue(TestParser.checkParser(input,expect,248))

    def test_49(self):
        input = """ Var: t;
                    Var: sp, yz;
                    Function: you
                    Parameter: q , d[5]
                    Body:
                    Var: a = "string", b;
                    Var: c = False;
                    foo(a + c);
                    While (True)  Do    
                        foo();
                        goo(a);
                        Break;                      
                    EndWhile.
                    For (i = 0, i < 10, i = i +2) Do
                        x = i;
                    EndFor.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,249))

    
    def test_50(self):
        input = """ 
                    Function: you
                    Parameter: q , d[5]
                    Body:                        
                    For (, , ) Do
                        x = i;
                    EndFor.
                    EndBody.            
            """
        expect = "Error on line 5 col 25: ,"
        self.assertTrue(TestParser.checkParser(input,expect,250))
    
    def test_51(self):
        input = """ 
                    Function: you
                    Parameter: q , d[5]
                    Body:                        
                    For (x = 1, , ) Do
                        x = i;
                    EndFor.
                    EndBody.            
            """
        expect ="Error on line 5 col 32: ,"
        self.assertTrue(TestParser.checkParser(input,expect,251))

    def test_52(self):
        input = """ 
                    Function: you
                    Parameter: q , d[5]
                    Body:                        
                    For (i = 1, i < 10 , ) Do
                        x = i;
                    EndFor.
                    EndBody.            
            """
        expect = "Error on line 5 col 41: )"
        self.assertTrue(TestParser.checkParser(input,expect,252))

    def test_53(self):
        # Sai 
        input = """ 
                    Function: you
                    Parameter: q , d[5]
                    Body:                        
                    For (i = a,i < 10, i = i + 1) Do
                        x = i;
                    EndFor.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,253))

    def test_54(self):
        input = """ 
                    Function: you
                    Parameter: q , d[5]
                    Body:                        
                    For (i = 1,i < 10, i = i + 1) Do
                    EndFor.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,254))

    def test_55(self):
        input = """ 
                    Function: you
                    Parameter: q , d[5]
                    Body:                        
                    For (i = 1,i < 10, i = i + 1)
                        
                    EndBody.            
            """
        expect = "Error on line 7 col 20: EndBody"
        self.assertTrue(TestParser.checkParser(input,expect,255))

    def test_56(self):
        input = """ 
                    Function: you
                    Parameter: q , d[5]
                    Body:                        
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,256))

    def test_57(self):
        input = """ 
                    Function: you
                    Parameter: q , d[5]
                    Body:                        
                    x = foo(x + y -z ) + goo(x[a - b]);
                    y = foo(2 * (x + goo(x)));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,257))

    def test_58(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body:  
                    x = -x;
                    y = -y;                        
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,258))

    def test_59(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body:  
                    x = -x;
                    y = -y;
                    z = !z;                                            
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,259))
    def test_60(self):
        input = """ Var: x[4][0][10];
                    Function: you
                    Parameter: x[3][4][6]
                    Body:
                    











                    EndBody.
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,260))

    def test_61(self):
        input = """ Var: x[4][0][10];
                    Function: you
                    Parameter: x[3][4][6]
                    Body:
                    While (a != 3)
                    Do
                    EndWhile.
                    EndBody.
        
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,261))

    def test_62(self):
        input = """ Var: x[4][0][10];
                    Function: you
                    Parameter: x[3][4][6]
                    Var: y;
                    Body:
                    While                            
                    EndWhile.
                    EndBody.            
            """
        expect = "Error on line 4 col 20: Var"
        self.assertTrue(TestParser.checkParser(input,expect,262))

    def test_63(self):
        input = """ Var: x[4][0][10];
                    Function: you
                    Parameter: x[3][4][6]
                    Body:
                    Var: a;
                    If (z == True) Then
                        Return 1;
                    EndIf.
                    While (True)  Do                          
                    EndWhile.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,263))

    def test_64(self):
        input = """ Var: x[4][0][10];
                    Function: you
                    Parameter: x[3][4][6]
                    Body:
                    Var: a;
                    If (z == True) Then
                        Return 1;
                    
                    While (True)  Do                          
                    EndWhile.
                    EndBody.            
            """
        expect = "Error on line 11 col 20: EndBody"
        self.assertTrue(TestParser.checkParser(input,expect,264))

    def test_65(self):
        input = """ Var: x = 1, y = 2., z = 3.5;
                    Function: you
                    Parameter: x , y[5]
                    Body:
                    Var: a, b, c;
                    If (z == True) Then
                        Return 1;
                    EndIf.
                    While (True)  Do                          
                    EndWhile.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,265))
    
    def test_66(self):
        input = r""" Var: x = 1, y = 2., z = 3.5;
                    Function: you
                    Parameter: x , y[5]
                    Body:
                    Var: a;
                    Var: a = "abcasf \n asfasfas";
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,266))


    def test_67(self):
        input = """ Var: x;
                    Function: fact
                    Parameter: n
                    Body:
                    If n == 0 Then
                    Return 1;
                    Else
                    Return n * fact (n - 1);
                    EndIf.
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,267))

    def test_68(self):
        input = """ Function: main
                    Body:
                    x = 10;
                    fact (x);
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,268))

    def test_69(self):
        input = """ Function: main
                    Body:
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,269))
    
    def test_70(self):
        input = """ Function:
                    Body:
                    EndBody.
                    """
        expect = "Error on line 2 col 20: Body"
        self.assertTrue(TestParser.checkParser(input,expect,270))

    def test_71(self):
        input = """ Function: main
                    """
        expect = "Error on line 2 col 20: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,271))

    def test_72(self):
        input = """
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,272))
    
    def test_73(self):
        input = """Function: main
                    Body:
                    Var: r = 10., v;
                    v = (4. / 3.) *. 3.14 *. r *. r *. r;
                    EndBody.

                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,273))
   

    def test_74(self):
        input = """Function: main
                    Body:
                    x = y + (z -q) *. 10;
                    x = n >=. z;
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,274))

   
    def test_75(self):
        input = """Function: main
                    Body:
                    x = y + (z -q) *. 10;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    x = n >=. z;
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,275))

    def test_76(self):
        input = """ Var: a = 5;
                    Var: b[5];
                    Var: c, d = 6, e;
                    Function: main
                    Body:
                    x = y + (z -q) *. 10;
                    x = n >=. z;
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,276))

    def test_77(self):
        input = """ Var: a = "Its string";
                    Var: b[5];
                    Var: c, d = 6, e;
                    Function: main
                    Body:
                    x = y + (z -q) *. 10;
                    x = n >=. z;
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,277))

    def test_78(self):
        input = """ Var: a = "Its string";
                    Var: b[5];
                    Var: c, d = 6, e;
                    Function: main
                    Body:
                    x = y + (z -q) *. 10;
                    x = n >=. z;
                    ng = (arr[b[x[a+1*5 - (a - 9)]]] + 3) * y;
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,278))

    def test_79(self):
        input = """ Var: a = "Its string";
                    Var: b[5] = 1, p, y = 5;
                    Var: c, d = 6, e;
                    Function: main
                    Body:
                    If n =/= m Then
                        Return n[m] - 5;
                    Else
                        Return m + fact(n-1);
                    EndIf.
                    EndBody.
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,279))

    def test_80(self):
        input = """ Var a = "Its string"
                    Var: b[5] = 1, p, y = 5;
                    Var: c, d = 6, e;
                    Function: main
                    Body:
                    If n =/= m Then
                        Return n[m] - 5;
                    Else
                        Return m + fact(n-1);
                    EndIf.
                    EndBody.
                    """
        expect = "Error on line 1 col 5: a"
        self.assertTrue(TestParser.checkParser(input,expect,280))

    def test_81(self):
        input = """ Var: a = "Its string";
                    Var: b[5] = 1, p, y = 5;
                    Var: c, d = 6, e;
                    Function: cHECK
                    Body
                    a[3 + foo(2)] = a[b[2][3]] + 4;
                    If n =/= m Then
                        Return n[m] - 5;
                    Else
                        Return m + fact(n-1);
                    EndIf.
                    EndBody.
                    """
        expect = "Error on line 6 col 20: a"
        self.assertTrue(TestParser.checkParser(input,expect,281))

    def test_82(self):
        input = """ Var: x;
                    Function: you
                    Parameter: x , y[5], asfasf, afa_0123, asfas_____
                    Body:
                    Var: a, b, c = "string";
                    Var: a = False;
                    While (True)  Do    
                        While (True)  Do    
                            While (True)  Do    
                                Break;                      
                            EndWhile.
                            Break;                      
                        EndWhile.
                        Break;                      
                    EndWhile.
                    While (True)  Do    
                        foo();
                        goo(a);
                        Break;                      
                    EndWhile.
                    While (True)  Do    
                        foo();
                        goo(a);
                        Break;                      
                    EndWhile.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,282))

    def test_83(self):
        input = """ 
                    Var: t;
                    Var: sp, yz;
                    Function: you
                    Body:
                    If (z == True) Then
                        x = d[y *. z +. t -. c \ 10];
                        Return 1;
                    ElseIf x != 4.e5 Then
                        x = (a + b) * y - z + (sp *. yz);
                    Else
                        Continue;
                    EndIf.
                    If (z == True) Then
                        x = d[y *. z +. t -. c \ 10];
                        Return 1;
                    ElseIf x != 4.e5 Then
                        x = (a + b) * y - z + (sp *. yz);
                    Else
                        Continue;
                    EndIf.
                    If (z == True) Then
                        x = d[y *. z +. t -. c \ 10];
                        Return 1;
                    ElseIf x != 4.e5 Then
                        x = (a + b) * y - z + (sp *. yz);
                    Else
                        Continue;
                    EndIf.
                    While (True)  Do    
                        foo();
                        goo(a);
                        Break;                      
                    EndWhile.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,283))
    def test_84(self):
        input = """ Var: x, z = 3.5;
                    Function: main
                    
                    Body:
                    Var: a = "string", b;
                    Var: c = False;
                    foo(a + c);
                    If (z == True) Then
                        x = d[y *. z +. t -. c \ 10];
                        Return 1;
                    Else
                        Continue;
                    EndIf.
                    While (True)  Do    
                        foo();
                    EndWhile.
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,284))
    def test_85(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                Do x = y;
                While a > b && u < m;
                EndBody."""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,285))

    def test_86(self):
        input = """ Var: x;
                Function: fact
                Parameter: n, y
                Body:
                Do x = y;
                While a > b;
                EndBody."""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,286))

    
    def test_87(self):
        input = """ Var: x, y;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,287))

    def test_88(self):
        input = """ Var: x, y = 1, a41;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,288))

    def test_89(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body:                          
                    If(a != b) Then
                        Break;
                    EndIf.                                    
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,289))

    def test_90(self):
        input = """ Var: uh;
                    Function: you                        
                    Body:  
                    x = x == a;                        
                    If(z > 5) Then
                        Break;
                    EndIf.
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
                    """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,290))
    
    def test_91(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body:                          
                    If(q <= q *2) Then
                        Break;
                    EndIf.                    
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,291))

    def test_92(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body: 
                    If(q <=. q *2) Then
                        Break;
                    EndIf.                    
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,292))

    def test_93(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body:
                    If(m >= m *. 3.) Then
                        Break;
                    EndIf.                            
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,293))

    def test_94(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body:  
                    If(ok =/= 5) Then
                        Break;
                    EndIf.                                  
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,294))

    def test_95(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body: 
                    If((a > b) && (c < d)) Then
                        Break;
                    EndIf.                              
                    x = foo() + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,295))

    def test_96(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body:                          
                    
                    x = foo("str") + goo(x);
                    y = foo(x + goo(x));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,296))

    def test_97(self):
        input = """           """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,297))

    def test_98(self):
        input = """ Var: uh;
                    Function: you
                    Parameter: q , d[5]
                    Body:                                       
                    x = foo(0XAB) + goo(0o12);
                    y = foo(x + goo(True));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,298))

    def test_99(self):
        input = """ Var: asfasdfasdfasdfkasjfasj;
                    Function: main
                    Parameter: q , d[5]
                    Body:                                       
                    asfaskfasjfkasjf = asfasdfasdfa+ asfasfasdfasdfasdf+asfasdfasdfasdfas;
                    y = foo(x + goo(True));
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,299))
        
    def test_100(self):
        input = """ 
                    Function: main
                    Body:                                       
                    EndBody.            
            """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,300))

    def test_101(self):
        """Simple program: int main() {} """
        input = """Var: x;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,301))

    
    def test_102(self):
        """Miss ) int main( {}"""
        input = """Var: ;"""
        expect = "Error on line 1 col 5: ;"
        self.assertTrue(TestParser.checkParser(input,expect,302))