Version 1.1

Change current directory to initial/src where there is file run.py
Type: python run.py gen 
Then type: python run.py test LexerSuite
Then type: python run.py test ParserSuite

Change Log from version 1.0
- Comment out line 17, 18 of TestUtils.py
- Add line 19 if TestUtils.py: file.write(inputStr)
- Add three more tests in LexerSuite.py for strings 

